<?php $__env->startSection('content'); ?>
	<div class="contact-us-section section-spacing">
		<div class="container">
			<div class="theme-title-one">
				<h2>Crear Empresas</h2>
				<!-- <p>A tale of a fateful trip that started from this tropic port aboard this tiny ship today stillers</p> -->
			</div> <!-- /.theme-title-one -->
			<div class="row">
				<div class="col-sm-1"></div>

				<div class="clearfix main-content no-gutters col-sm-10">
				
					<div class="col-lg-12 col-12">
						<div class="form-wrapper theme-form-one form-validation">
							<?php echo Form::open(array('route' => 'empresas.store', 'data-parsley-validate' => 'parsley')); ?>


							<?php echo e(csrf_field()); ?>

								<div class="row">
									<div class="col-sm-6 col-12">
										<label for="Nombre">Nombre *</label>
										<input type="text"  name="Nombre" required>
									</div>									
								</div> <!-- /.row -->
								<div class="row">
									<div class="col-sm-6 col-12">
										<label for="Identificacion">Identificacion *</label>
										<input type="text"  name="Identificacion" required>
									</div>
									<div class="col-sm-6 col-12">
										<label for="Identificacion">Tipo Empresa *</label>
										<?php echo e(Form::select('IdTipoEmpresa', $tipoEmpresa->pluck('TipoEmpresa', 'IdTipoEmpresa'), null, ['class' => 'form-control', 'id' => 'IdTipoEmpresa'])); ?>

									</div>
								</div> <!-- /.row -->
								<div class="row">
									<div class="col-sm-6 col-12">
										<label for="Descripcion">Descripción *</label>
										<input type="text"  name="Descripcion">
									</div>
									<div class="col-sm-6 col-12">
										<label for="Sector">Sector *</label>
										<?php echo e(Form::select('IdSector', $sector->pluck('Sector', 'IdSector'), null, ['class' => 'form-control', 'id' => 'IdSector'])); ?>

									</div>
								</div>								
								<div class="row">
									<div class="col-sm-6 col-12">
										<label for="Contacto">Contacto *</label>
										<input type="text"  name="Contacto" required>
									</div>
									<div class="col-sm-6 col-12">
										<label for="Email">Email *</label>
										<input type="email"  name="Email" required>
									</div>
								</div> <!-- /.row -->
								<div class="row">
									<div class="col-sm-4 col-12">
										<label for="NoEmpleados">Número Empleados *</label>
										<input type="number"  name="NoEmpleados" required>
									</div>
									<div class="col-sm-4 col-12">
										<label for="TipoRiesgo">TipoRiesgo *</label>
										<input type="number"  name="TipoRiesgo" required>
									</div>
									<div class="col-sm-4 col-12">
										<label for="ARL">ARL *</label>
										<input type="text"  name="ARL" required>
									</div>

								</div> <!-- /.row -->
								<div class="row">
									
									<div class="col-sm-6 col-12" style="padding: 0 auto;">
										
										<button type="submit" class="theme-button-one btn-block">Guardar</button>
										
									</div>
									<div class="col-sm-6 col-12">
										<button class="theme-button-one btn-block" onclick="window.location='<?php echo e(route("empresas.index")); ?>'">Cancelar</button>
										
									</div>
								</div>
							<?php echo Form::close(); ?>

						</div> <!-- /.form-wrapper -->
					</div> <!-- /.col- -->
				 <!-- /.main-content -->
					
				</div> <!-- /.main-content -->

				<div class="col-sm-1"></div>
			</div>
		</div> <!-- /.container -->

		
	</div> <!-- /.contact-us-section -->			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>